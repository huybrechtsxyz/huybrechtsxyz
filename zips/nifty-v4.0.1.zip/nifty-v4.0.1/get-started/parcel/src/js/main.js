// Import only the Bootstrap components we need
// ---------------------------------------------------------------------------------
import { Dropdown, ScrollSpy } from "bootstrap";



// Nifty components
// ---------------------------------------------------------------------------------
//import Toggler from "./nifty/Components/Toggler";
import SmoothDropdown from "./nifty/Components/SmoothDropdown";
import SidebarToggler from "./nifty/Components/SidebarToggler";
import MainNavigation from "./nifty/Components/MainNavigation";
import ColorModeSwitcher from "./nifty/Components/ColorModeSwitcher";
