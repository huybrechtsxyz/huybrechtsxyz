const GetSelector = {
   find(selector, element = document.documentElement) {
      return [].concat(...Element.prototype.querySelectorAll.call(element, selector))
   },

   findOne(selector, element = document.documentElement) {
      return Element.prototype.querySelector.call(element, selector)
   }
}

export default GetSelector