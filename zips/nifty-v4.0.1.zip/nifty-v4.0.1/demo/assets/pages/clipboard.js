document.addEventListener( "DOMContentLoaded", () => {

   const clipboardEl = document.querySelectorAll( "._dm-clipboard" );
   new ClipboardJS( "._dm-clipboard" );

})
